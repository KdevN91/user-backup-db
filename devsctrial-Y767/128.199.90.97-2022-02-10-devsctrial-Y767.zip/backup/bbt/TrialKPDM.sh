#!/bin/bash
# USER TRIAL GRPC by 2112354428 Wed 09 Feb 2022 03:10:54 AM +08
exp=$(grep -wE "^#& TrialKPDM" "/etc/xray/vmessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& TrialKPDM 2022-02-11/,/^},{/d" /etc/xray/vmessgrpc.json
exp=$(grep -wE "^#& TrialKPDM" "/etc/xray/vlessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& TrialKPDM 2022-02-11/,/^},{/d" /etc/xray/vlessgrpc.json
systemctl restart xr-vl-ntls.service > /dev/null 2>&1
systemctl restart xr-vl-tls.service  > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialKPDM
rm /etc/.maAsiss/info-user-grpc/TrialKPDM
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialKPDM ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialKPDM
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialKPDM ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialKPDM
rm -f /etc/.maAsiss/TrialKPDM
rm -f /etc/.maAsiss/TrialKPDM.sh
