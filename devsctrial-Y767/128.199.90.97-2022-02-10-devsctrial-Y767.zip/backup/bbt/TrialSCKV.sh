#!/bin/bash
# USER TRIAL VMESS by 5204832228 Mon 07 Feb 2022 08:32:56 PM +08
exp=$(grep -wE "^### TrialSCKV" "/etc/xray/vmesstls.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^### TrialSCKV 2022-02-09/,/^},{/d" /etc/xray/vmesstls.json
exp=$(grep -wE "^### TrialSCKV" "/etc/xray/vmessnone.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^### TrialSCKV 2022-02-09/,/^},{/d" /etc/xray/vmessnone.json
systemctl restart xr-vm-ntls.service > /dev/null 2>&1
systemctl restart xr-vm-tls.service  > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/5204832228/user_ray/TrialSCKV
rm /etc/.maAsiss/info-user-v2ray/TrialSCKV
[[ -e /etc/.maAsiss/db_reseller/5204832228/user_ray/TrialSCKV ]] && rm /etc/.maAsiss/db_reseller/5204832228/user_ray/TrialSCKV
[[ -e /etc/.maAsiss/db_reseller/5204832228/trial-fold/TrialSCKV ]] && rm /etc/.maAsiss/db_reseller/5204832228/trial-fold/TrialSCKV
rm -f /etc/.maAsiss/TrialSCKV
rm -f /etc/.maAsiss/TrialSCKV.sh
