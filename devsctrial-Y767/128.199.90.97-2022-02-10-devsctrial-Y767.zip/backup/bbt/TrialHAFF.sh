#!/bin/bash
# USER TRIAL GRPC by 2112354428 Wed 09 Feb 2022 11:58:57 AM +08
exp=$(grep -wE "^### TrialHAFF" "/etc/xray/vmessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^### TrialHAFF 2022-02-11/,/^},{/d" /etc/xray/vmessgrpc.json
exp=$(grep -wE "^### TrialHAFF" "/etc/xray/vlessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^### TrialHAFF 2022-02-11/,/^},{/d" /etc/xray/vlessgrpc.json
systemctl restart xr-vl-ntls.service > /dev/null 2>&1
systemctl restart xr-vl-tls.service  > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialHAFF
rm /etc/.maAsiss/info-user-grpc/TrialHAFF
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialHAFF ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialHAFF
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialHAFF ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialHAFF
rm -f /etc/.maAsiss/TrialHAFF
rm -f /etc/.maAsiss/TrialHAFF.sh
