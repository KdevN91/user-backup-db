#!/bin/bash
# USER TRIAL VLESS by 2112354428 Wed 09 Feb 2022 01:32:41 AM +08
exp=$(grep -wE "^#& Trial5B45" "/etc/xray/vlessnone.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& Trial5B45 2022-02-11/,/^},{/d" /etc/xray/vlessnone.json
exp=$(grep -wE "^#& Trial5B45" "/etc/xray/vlesstls.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& Trial5B45 2022-02-11/,/^},{/d" /etc/xray/vlesstls.json
systemctl restart xr-vl-ntls.service > /dev/null 2>&1
systemctl restart xr-vl-tls.service  > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/2112354428/user_vless/Trial5B45
rm /etc/.maAsiss/info-user-vless/Trial5B45
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_vless/Trial5B45 ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_vless/Trial5B45
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/Trial5B45 ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/Trial5B45
rm -f /etc/.maAsiss/Trial5B45
rm -f /etc/.maAsiss/Trial5B45.sh
