#!/bin/bash
# USER TRIAL GRPC by 2112354428 Wed 09 Feb 2022 03:07:11 AM +08
exp=$(grep -wE "^#& TrialWYCD" "/etc/xray/vmessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& TrialWYCD 2022-02-11/,/^},{/d" /etc/xray/vmessgrpc.json
exp=$(grep -wE "^#& TrialWYCD" "/etc/xray/vlessgrpc.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^#& TrialWYCD 2022-02-11/,/^},{/d" /etc/xray/vlessgrpc.json
systemctl restart xr-vl-ntls.service > /dev/null 2>&1
systemctl restart xr-vl-tls.service  > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialWYCD
rm /etc/.maAsiss/info-user-grpc/TrialWYCD
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialWYCD ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_grpc/TrialWYCD
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialWYCD ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialWYCD
rm -f /etc/.maAsiss/TrialWYCD
rm -f /etc/.maAsiss/TrialWYCD.sh
