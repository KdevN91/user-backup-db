#!/bin/bash
# USER TRIAL VMESS by 2112354428 Mon 07 Feb 2022 04:48:01 AM +08
exp=$(grep -wE "^### TrialG2BE" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^### TrialG2BE 2022-02-09/,/^},{/d" /etc/xray/config.json
systemctl restart xr-vm-ntls.service > /dev/null 2>&1
systemctl restart xr-vm-tls.service  > /dev/null 2>&1
rm /etc/.maAsiss/db_reseller/2112354428/user_ray/TrialG2BE
rm /etc/.maAsiss/info-user-v2ray/TrialG2BE
[[ -e /etc/.maAsiss/db_reseller/2112354428/user_ray/TrialG2BE ]] && rm /etc/.maAsiss/db_reseller/2112354428/user_ray/TrialG2BE
[[ -e /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialG2BE ]] && rm /etc/.maAsiss/db_reseller/2112354428/trial-fold/TrialG2BE
rm -f /etc/.maAsiss/TrialG2BE
rm -f /etc/.maAsiss/TrialG2BE.sh
